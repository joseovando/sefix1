<?php

$search =  request('search');
$entrada = explode(' | ', $search);

if (stristr($search, '|') === FALSE) {
    $vistaCategoria = DB::table('vista_categorias')
        ->where('categoria', 'like', '%' . $search . '%')
        ->where('estado', '=', 1)
        ->orderBy('tipo', 'ASC')
        ->orderBy('categoria_padre', 'ASC')
        ->orderBy('categoria', 'ASC')
        ->first();
} else {
    $vistaCategoria = DB::table('vista_categorias')
        ->where('categoria_padre', 'like', '%' . $entrada[1] . '%')
        ->where('categoria', 'like', '%' . $entrada[0] . '%')
        ->where('estado', '=', 1)
        ->orderBy('tipo', 'ASC')
        ->orderBy('categoria_padre', 'ASC')
        ->orderBy('categoria', 'ASC')
        ->first();
}

if (!isset($vistaCategoria)) {
    $search_result = 0;
    $vistaCategoria = 0;
    $vistaIngresoProgramado = 0;
} else {
    $search_result = 1;

    if (request('tipo') == 1) {
        $vistaIngresoProgramado = DB::table('vista_ingreso_programado')
            ->where('id_categoria', '=', $vistaCategoria->id)
            ->where('estado_ingreso_programado', '=', 1)
            ->where('id_user_ingreso_programado', '=', auth()->id())
            ->orderBy('orden_categoria', 'ASC')
            ->first();
    } else {
        $vistaIngresoProgramado = DB::table('vista_egreso_programado')
            ->where('id_categoria', '=', $vistaCategoria->id)
            ->where('estado_egreso_programado', '=', 1)
            ->where('id_user_egreso_programado', '=', auth()->id())
            ->orderBy('orden_categoria', 'ASC')
            ->first();
    }
}
