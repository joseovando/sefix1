<?php

switch ($menu) {
    case 1:
        $titulo = "Ingreso Programado";
        $tipo = 1;
        break;
    case 2:
        $titulo = "Ingreso Ejecutado";
        $tipo = 1;
        break;
    case 3:
        $titulo = "Egreso Programado";
        $tipo = 2;
        break;
    case 4:
        $titulo = "Egreso Ejecutado";
        $tipo = 2;
        break;
}
