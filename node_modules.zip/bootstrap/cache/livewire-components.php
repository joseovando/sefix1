<?php return array (
  'select-categoria-component' => 'App\\Http\\Livewire\\SelectCategoriaComponent',
);