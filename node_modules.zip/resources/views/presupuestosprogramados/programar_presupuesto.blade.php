<form autocomplete="off" class="form-horizontal" id="form_guardar_programado">

    @csrf

    <div>
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>

                    {{-- Adicionar Subcategoria --}}
                    <th>
                        <input type="button" name="addRowButton" id="addRowCategoria" value="+"
                            class="btn btn-success btn-fab">
                    </th>
                    {{-- Adicionar Subcategoria --}}

                    {{-- Cambiar Categoria --}}
                    <th>
                        <div class="form-group">
                            <select onChange="" class="custom-select mr-sm-2" id="select_categoria"
                                name="select_categoria" @if ($navegador_mobile == 0) style="width:320px" @endif>
                                @foreach ($vistaCategoriaPadres as $vistaCategoriaPadre)
                                    @if ($vistaCategoriaPadre->plantilla == 1)
                                        <option value="{{ $vistaCategoriaPadre->id }}"
                                            @if ($id == $vistaCategoriaPadre->id) selected @endif>
                                            {{ $vistaCategoriaPadre->categoria }}
                                        </option>
                                    @else
                                        @if ($vistaCategoriaPadre->id_user == auth()->id())
                                            <option value="{{ $vistaCategoriaPadre->id }}"
                                                @if ($id == $vistaCategoriaPadre->id) selected @endif>
                                                {{ $vistaCategoriaPadre->categoria }}
                                            </option>
                                        @endif
                                    @endif
                                @endforeach
                            </select>
                            <input type="hidden" name="id_categoria" value="{{ $id }}">
                            <input type="hidden" name="tipo" value="{{ $tipo }}">
                            <input type="hidden" name="menu" value="{{ $menu }}">
                            <input type="hidden" name="mes_actual" value="{{ $mes_actual }}">
                            <input type="hidden" name="ano_actual" value="{{ $ano_actual }}">
                            <input type="hidden" name="cantidad_tr" value="{{ $cantidad_tr }}">
                            <input type="hidden" name="tr_adicional" id="tr_adicional" value="0">
                        </div>
                    </th>
                    {{-- Cambiar Categoria --}}

                    <th>Monto</th>
                    <th>Frecuencia</th>
                    <th>Sin Caducidad</th>
                    <th>Desde Fecha</th>
                    <th>Hasta Fecha</th>
                </tr>
            </thead>
            <tbody>
                @include('presupuestosprogramados.categoria_search')
                <div id="div_inicial">
                    @include('presupuestosprogramados.categoria_adicional')
                    @include('presupuestosprogramados.categoria_ajax')
                    @include('presupuestosprogramados.categoria_inicial')
                </div>
            </tbody>
            <tfoot>
                <th></th>
                <th bgcolor="#7adf7f" align="right">Total Programado</th>
                <th bgcolor="#7adf7f" align="right">
                    <div id="total_programado">
                        <span>{{ $monto_total }}</span>
                    </div>
                </th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tfoot>
        </table>
    </div>
    <div class="row">
        <div class="card-footer ml-auto mr-auto">
            <button type="submit" id="guardarProgramado" class="btn btn-primary">{{ __('Guardar') }}</button>
        </div>
    </div>
</form>
