@foreach ($vistaCategorias as $vistaCategoria)
    {{-- categorias plantilla --}}
    @if ($vistaCategoria->plantilla == 1)
        @include('presupuestosprogramados.categoria_inicial_plantilla')
    @else
        {{-- categorias plantilla --}}

        {{-- categorias usuario --}}
        @if ($vistaCategoria->id_user == auth()->id())
            @include('presupuestosprogramados.categoria_inicial_usuario')
        @endif
        {{-- categorias usuario --}}
    @endif
@endforeach
