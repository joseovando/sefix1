  <script>
      $(document).ready(function() {
          $("#form_guardar_programado").validate();
      });

      function momentGet(date) {
          var userDate = date;
          var date_string = moment(userDate, "DD.MM.YY").format("YYYY-MM-DD");

          if (date_string == "Invalid date") {
              date_string = '';
          }

          return date_string;
      }

      function momentSet(date) {
          var userDate = date;
          var date_string = moment(userDate, "YYYY-MM-DD").format("DD/MM/YY");

          if (date_string == "Invalid date") {
              date_string = '';
          }

          return date_string;
      }
  </script>

  <script type="text/javascript" class="init">
      $(document).ready(function() {
          $('#example').DataTable({
              scrollY: '50vh',
              scrollX: '50vh',
              scrollCollapse: true,
              paging: false,
              ordering: false,
              info: false,
              searching: false,
          });
      });
  </script>

  <script>
      $(function() {
          /* valores iniciales Storage */
          var valor_inicial = 0;
          localStorage.setItem("contador_search", valor_inicial);
          localStorage.setItem("contador_ajax", valor_inicial);
          localStorage.setItem("contador_adicional", valor_inicial);
          localStorage.setItem("id_categoria", @json($id));
          localStorage.setItem("mes_actual", @json($mes_actual));
          localStorage.setItem("ano_actual", @json($ano_actual));
          localStorage.setItem("llave_ajax", valor_inicial);
      });
  </script>

  <script>
      function nav(value) {
          if (value != "") {
              location.href = value;
          }
      }
  </script>

  <script type="text/javascript">
      $(document).ready(function() {
          $('#buscarCategoria').click(function(e) {
              e.preventDefault();

              var _token = $("input[name='_token']").val();
              var search = $("#autoComplete").val();
              var tipo = @json($tipo);

              $.ajax({
                  url: "{{ route('presupuestosprogramados.search') }}",
                  type: 'POST',
                  data: {
                      _token: _token,
                      search: search,
                      tipo: tipo,
                  },
                  success: function(data) {
                      cargarSearch(data);
                  }
              });
          });

          function cargarSearch(data) {
              var search_result = data.search_result;
              var vistaCategoria = data.vistaCategoria;
              var vistaIngresoProgramado = data.vistaIngresoProgramado;
              var vistaCategoriaInicial = @json($vistaCategorias);

              /* ocultar categorias iniciales */
              for (var i = 0; i < vistaCategoriaInicial.length; ++i) {
                  var tr = "tr_" + vistaCategoriaInicial[i].id;
                  let element_exist = !!document.getElementById(tr);
                  let element = document.getElementById(tr);

                  if (element_exist == true) {
                      element.setAttribute("hidden", "hidden");
                  }
              };

              /* mostrar categorias search */
              var tr_search = parseInt(localStorage.getItem("contador_search"));
              var tr_hidden = "tr_search_" + tr_search;
              let element = document.getElementById(tr_hidden);
              element.removeAttribute("hidden", "hidden");

              /* cargar data a categoria search */
              id_search = "id_search_" + tr_search;
              id_categoria_search = "id_categoria_search_" + tr_search;
              categoria_search = "categoria_search_" + tr_search;
              monto_search = "monto_search_" + tr_search;
              frecuencia_search = "frecuencia_search_" + tr_search;
              sin_caducidad_search = "sin_caducidad_search_" + tr_search;
              inicio_search = "inicio_search_" + tr_search;
              fin_search = "fin_search_" + tr_search;
              div_search = "div_search_" + tr_search;
              div2_search = "div2_search_" + tr_search;

              document.getElementById(categoria_search).innerHTML = vistaCategoria.categoria;
              document.getElementById(id_categoria_search).value = vistaCategoria.id;

              if (vistaIngresoProgramado !== null) {

                  document.getElementById(id_search).value = vistaIngresoProgramado.id;
                  document.getElementById(monto_search).value = vistaIngresoProgramado.monto_programado;
                  document.getElementById(frecuencia_search).value = vistaIngresoProgramado.id_frecuencia;

                  /* reglas de validacion */
                  if (vistaIngresoProgramado.id_frecuencia == 1) {
                      document.getElementById(inicio_search).setAttribute("required", "");
                      document.getElementById(div_search).style.display = 'none';
                      document.getElementById(fin_search).removeAttribute("required");
                      document.getElementById(div2_search).style.display = 'none';
                      document.getElementById(sin_caducidad_search).removeAttribute("required");
                  }

                  if (vistaIngresoProgramado.id_frecuencia > 1) {
                      document.getElementById(inicio_search).setAttribute("required", "");
                      document.getElementById(div_search).style.display = 'initial';
                      document.getElementById(fin_search).setAttribute("required", "");
                      document.getElementById(div2_search).style.display = 'initial';
                  }

                  if (vistaIngresoProgramado.sin_caducidad == 1) {
                      document.getElementById(sin_caducidad_search).checked = true;
                      document.getElementById(div_search).style.display = 'none';
                      document.getElementById(fin_search).removeAttribute("required");
                  }

                  /* cargar data a categoria search */
                  document.getElementById(inicio_search).value = momentSet(vistaIngresoProgramado.fecha_inicio);
                  document.getElementById(fin_search).value = momentSet(vistaIngresoProgramado.fecha_fin);
              }

          }

          $('#cambiar_mes_programado').click(function(e) {
              e.preventDefault();

              var _token = $("input[name='_token']").val();
              var ano_actual = $("#ano_actual").val();
              var mes_actual = $("#mes_actual").val();
              var llave_form = 1;
              var tipo = @json($tipo);
              var llave_ajax = parseInt(localStorage.getItem("llave_ajax"));

              if (llave_ajax == 1) {
                  var id_categoria = parseInt(localStorage.getItem("id_categoria"));
              } else {
                  var id_categoria = @json($id);
              }

              $.ajax({
                  url: "{{ route('presupuestosprogramados.cambiar_fecha') }}",
                  type: 'POST',
                  data: {
                      _token: _token,
                      ano_actual: ano_actual,
                      mes_actual: mes_actual,
                      llave_form: llave_form,
                      tipo: tipo,
                      id_categoria: id_categoria
                  },
                  success: function(data) {
                      console.log(data);
                      localStorage.setItem("id_categoria", data.id_categoria);
                      localStorage.setItem("mes_actual", data.mes_actual);
                      localStorage.setItem("ano_actual", data.ano_actual);

                      if (llave_ajax == 1) {
                          cargarTablaSelect(data)
                      } else {
                          cargarTabla(data);
                      }
                  }
              });
          });

          function cargarTabla(data) {
              var vistaCategoria = data.vistaCategorias;
              var id_user = @json(auth()->id());
              var id_ingreso_programado = data.id_ingreso_programado;
              var monto = data.monto;
              var id_frecuencia = data.id_frecuencia;
              var caducidad = data.caducidad;
              var fecha_inicio = data.fecha_inicio;
              var fecha_fin = data.fecha_fin;

              for (var i in vistaCategoria) {

                  input_id_inicial = "id_" + vistaCategoria[i].id;
                  input_monto_inicial = "monto_" + vistaCategoria[i].id;
                  input_frecuencia_inicial = "frecuencia_" + vistaCategoria[i].id;
                  input_sin_caducidad_inicial = "sin_caducidad_" + vistaCategoria[i].id;
                  input_inicio_inicial = "inicio_" + vistaCategoria[i].id;
                  input_fin_inicial = "fin_" + vistaCategoria[i].id;
                  div_inicial = "div_" + vistaCategoria[i].id;
                  div2_inicial = "div2_" + vistaCategoria[i].id;

                  /* resetear categorias inicial */
                  let element_exist = !!document.getElementById(input_id_inicial);
                  if (element_exist == true) {
                      document.getElementById(input_id_inicial).value = '';
                      document.getElementById(input_monto_inicial).value = '';
                      document.getElementById(input_monto_inicial).removeAttribute("required");
                      document.getElementById(input_frecuencia_inicial).value = '';
                      document.getElementById(input_frecuencia_inicial).removeAttribute("required");
                      document.getElementById(input_sin_caducidad_inicial).checked = false;
                      document.getElementById(input_sin_caducidad_inicial).removeAttribute("required");
                      document.getElementById(input_inicio_inicial).value = '';
                      document.getElementById(input_inicio_inicial).removeAttribute("required");
                      document.getElementById(input_fin_inicial).value = '';
                      document.getElementById(input_fin_inicial).removeAttribute("required");
                      document.getElementById(div_inicial).style.display = 'initial';
                      document.getElementById(div2_inicial).style.display = 'initial';
                  }

                  if (vistaCategoria[i].plantilla == 1) {

                      if (monto[vistaCategoria[i].id] > 0) {

                          /* cargar data a categoria */
                          document.getElementById(input_id_inicial).value = id_ingreso_programado[
                              vistaCategoria[
                                  i].id];
                          document.getElementById(input_monto_inicial).value = monto[vistaCategoria[i]
                              .id];
                          document.getElementById(input_frecuencia_inicial).value = id_frecuencia[
                              vistaCategoria[
                                  i].id];
                          document.getElementById(input_sin_caducidad_inicial).value = caducidad[
                              vistaCategoria[i]
                              .id];

                          if (caducidad[vistaCategoria[i].id] == 1) {
                              document.getElementById(input_sin_caducidad_inicial).checked = true;
                          }

                          document.getElementById(input_inicio_inicial).value = momentSet(fecha_inicio[
                              vistaCategoria[i]
                              .id]);
                          document.getElementById(input_fin_inicial).value = momentSet(fecha_fin[
                              vistaCategoria[i]
                              .id]);

                          /* reglas de validacion */
                          if (id_frecuencia[vistaCategoria[i].id] == 1) {
                              document.getElementById(input_inicio_inicial).setAttribute("required", "");
                              document.getElementById(div_inicial).style.display = 'none';
                              document.getElementById(input_fin_inicial).removeAttribute("required");
                              document.getElementById(div2_inicial).style.display = 'none';
                              document.getElementById(input_sin_caducidad_inicial).removeAttribute(
                                  "required");
                          }

                          if (id_frecuencia[vistaCategoria[i].id] > 1) {
                              document.getElementById(input_inicio_inicial).setAttribute("required", "");
                              document.getElementById(div_inicial).style.display = 'initial';
                              document.getElementById(input_fin_inicial).setAttribute("required", "");
                              document.getElementById(div2_inicial).style.display = 'initial';
                          }

                          if (caducidad[vistaCategoria[i].id] == 1) {
                              document.getElementById(div_inicial).style.display = 'none';
                              document.getElementById(input_fin_inicial).removeAttribute("required");
                          }
                      } else {
                          let element_exist = !!document.getElementById(input_monto_inicial);

                          if (element_exist == true) {
                              document.getElementById(input_monto_inicial).value = ''
                          }
                      }
                  }

                  if (vistaCategoria[i].id_user == id_user) {

                      if (monto[vistaCategoria[i].id] > 0) {

                          /* cargar data a categoria */
                          document.getElementById(input_id_inicial).value = id_ingreso_programado[
                              vistaCategoria[
                                  i].id];
                          document.getElementById(input_monto_inicial).value = monto[vistaCategoria[i]
                              .id];
                          document.getElementById(input_frecuencia_inicial).value = id_frecuencia[
                              vistaCategoria[
                                  i].id];
                          document.getElementById(input_sin_caducidad_inicial).value = caducidad[
                              vistaCategoria[i]
                              .id];

                          if (caducidad[vistaCategoria[i].id] == 1) {
                              document.getElementById(input_sin_caducidad_inicial).checked = true;
                          }

                          document.getElementById(input_inicio_inicial).value = momentSet(fecha_inicio[
                              vistaCategoria[i]
                              .id]);
                          document.getElementById(input_fin_inicial).value = momentSet(fecha_fin[
                              vistaCategoria[i]
                              .id]);

                          /* reglas de validacion */
                          if (id_frecuencia[vistaCategoria[i].id] == 1) {
                              document.getElementById(input_inicio_inicial).setAttribute("required", "");
                              document.getElementById(div_inicial).style.display = 'none';
                              document.getElementById(input_fin_inicial).removeAttribute("required");
                              document.getElementById(div2_inicial).style.display = 'none';
                              document.getElementById(input_sin_caducidad_inicial).removeAttribute(
                                  "required");
                          }

                          if (id_frecuencia[vistaCategoria[i].id] > 1) {
                              document.getElementById(input_inicio_inicial).setAttribute("required", "");
                              document.getElementById(div_inicial).style.display = 'initial';
                              document.getElementById(input_fin_inicial).setAttribute("required", "");
                              document.getElementById(div2_inicial).style.display = 'initial';
                          }

                          if (caducidad[vistaCategoria[i].id] == 1) {
                              document.getElementById(div_inicial).style.display = 'none';
                              document.getElementById(input_fin_inicial).removeAttribute("required");
                          }
                      } else {
                          let element_exist = !!document.getElementById(input_monto_inicial).value;

                          if (element_exist == true) {
                              document.getElementById(input_monto_inicial).value = ''
                          }
                      }
                  }
              }
          }

          function desactivarCategoria(id) {
              var check = "check_" + id;
              var tr = "tr_" + id;

              if (document.getElementById(check).checked == false) {
                  var base_path = '{{ url('/') }}';
                  $.ajax({
                      url: base_path + "/presupuestosprogramados/" + id + "/desactivar_categorias",
                      method: 'GET',
                      success: function(data) {
                          let element = document.getElementById(tr);
                          element.setAttribute("hidden", "hidden");
                      }
                  });
              }
          }

          $('#activarCategoria').click(function(e) {
              e.preventDefault();
              var _token = $("input[name='_token']").val();
              var vistaCategoria = @json($vistaCategorias);
              var check_categorias = [];

              for (var i in vistaCategoria) {
                  var check = "check_" + vistaCategoria[i].id;
                  check_categorias[vistaCategoria[i].id] = document.getElementById(check).checked;
              }

              $.ajax({
                  url: "{{ route('presupuestosprogramados.activar_categorias') }}",
                  type: 'POST',
                  data: {
                      _token: _token,
                      vistaCategoria: vistaCategoria,
                      check_categorias: check_categorias,
                  },
                  success: function(data) {
                      var vista_categoria = data.vistaCategorias;
                      var arrayDisabled = data.arrayDisabled;

                      for (var i in vista_categoria) {
                          tr = "tr_" + vista_categoria[i].id;
                          let element = document.getElementById(tr);

                          console.log(arrayDisabled[vista_categoria[i].id]);
                          if (arrayDisabled[vista_categoria[i].id] == 1) {
                              element.setAttribute("hidden", "hidden");
                          } else {
                              element.removeAttribute("hidden", "hidden");
                          }
                      }

                      totalProgramado();
                      printMsg(data);
                  }
              });
          });
      });
  </script>

  <script>
      function printMsg(data) {
          console.log(data);
          Swal.fire({
              position: 'top-end',
              icon: 'success',
              title: 'Registro Guardado Correctamente, Información Actualizada',
              showConfirmButton: false,
              timer: 2000
          })
      }

      function cargarTablaInicial(data) {
          var presupuesto_id = data.presupuesto_id;
          var categoria_id = data.categoria_id;

          for (var i in presupuesto_id) {
              var input_id = "id_" + categoria_id[i];
              let element_exist = !!document.getElementById(input_id);

              if (element_exist == true) {
                  document.getElementById(input_id).value = presupuesto_id[i];
              }
          };
      }

      function cargarTablaAdicional(data) {

          var nueva_categoria_id = data.nueva_categoria_id;
          var categoria_adicional = data.categoria_adicional;
          var monto_adicional = data.monto_adicional;
          var frecuencia_adicional = data.frecuencia_adicional;
          var caducidad_adicional = data.caducidad_adicional;
          var inicio_adicional = data.inicio_adicional;
          var fin_adicional = data.fin_adicional;
          var contador_ajax = parseInt(localStorage.getItem("contador_ajax"));

          /* Categorias Adicionales */
          for (var i in categoria_adicional) {

              neo_i = parseInt(i) + parseInt(contador_ajax);

              /* ocultar y resetear categorias adicionales */
              var tr = "tr_adicional_" + i;
              let element_exist = !!document.getElementById(tr);
              let element = document.getElementById(tr);
              input_categoria_adicional = "subcategoria_adicional_" + i;
              input_monto_adicional = "monto_adicional_" + i;
              input_frecuencia_adicional = "frecuencia_adicional_" + i;
              input_sin_caducidad_adicional = "sin_caducidad_adicional_" + i;
              input_inicio_adicional = "inicio_adicional_" + i;
              input_fin_adicional = "fin_adicional_" + i;
              div_adicional = "div_adicional_" + i;
              div2_adicional = "div2_adicional_" + i;

              if (element_exist == true) {
                  element.setAttribute("hidden", "hidden");
                  document.getElementById(input_categoria_adicional).value = '';
                  document.getElementById(input_monto_adicional).value = '';
                  document.getElementById(input_monto_adicional).removeAttribute("required");
                  document.getElementById(input_frecuencia_adicional).value = '';
                  document.getElementById(input_frecuencia_adicional).removeAttribute("required");
                  document.getElementById(input_sin_caducidad_adicional).checked = false;
                  document.getElementById(input_sin_caducidad_adicional).removeAttribute("required");
                  document.getElementById(input_inicio_adicional).value = '';
                  document.getElementById(input_inicio_adicional).removeAttribute("required");
                  document.getElementById(input_fin_adicional).value = '';
                  document.getElementById(input_fin_adicional).removeAttribute("required");
                  document.getElementById(div_adicional).style.display = 'initial';
                  document.getElementById(div2_adicional).style.display = 'initial';
              }

              /* Categorias Ajax */
              if (monto_adicional[i] > 0) {

                  /* mostrar categorias ajax */
                  var tr_ajax = "tr_ajax_" + neo_i;
                  let element_ajax = document.getElementById(tr_ajax);
                  element_ajax.removeAttribute("hidden", "hidden");

                  /* cargar data a categoria ajax */
                  id_ajax = "id_ajax_" + neo_i;
                  categoria_ajax = "categoria_ajax_" + neo_i;
                  monto_ajax = "monto_ajax_" + neo_i;
                  frecuencia_ajax = "frecuencia_ajax_" + neo_i;
                  sin_caducidad_ajax = "sin_caducidad_ajax_" + neo_i;
                  inicio_ajax = "inicio_ajax_" + neo_i;
                  fin_ajax = "fin_ajax_" + neo_i;
                  div_ajax = "div_ajax_" + neo_i;
                  div2_ajax = "div2_ajax_" + neo_i;

                  document.getElementById(id_ajax).value = nueva_categoria_id[i];
                  document.getElementById(categoria_ajax).innerHTML = categoria_adicional[i];
                  document.getElementById(monto_ajax).value = monto_adicional[i];
                  document.getElementById(frecuencia_ajax).value = frecuencia_adicional[i];

                  /* reglas de validacion */
                  if (frecuencia_adicional[i] == 1) {
                      document.getElementById(inicio_ajax).setAttribute("required", "");
                      document.getElementById(div_ajax).style.display = 'none';
                      document.getElementById(fin_ajax).removeAttribute("required");
                      document.getElementById(div2_ajax).style.display = 'none';
                      document.getElementById(sin_caducidad_ajax).removeAttribute("required");
                  }

                  if (frecuencia_adicional[i] > 1) {
                      document.getElementById(inicio_ajax).setAttribute("required", "");
                      document.getElementById(div_ajax).style.display = 'initial';
                      document.getElementById(fin_ajax).setAttribute("required", "");
                      document.getElementById(div2_ajax).style.display = 'initial';
                  }

                  if (caducidad_adicional[i] == 1) {
                      document.getElementById(sin_caducidad_ajax).checked = true;
                      document.getElementById(div_ajax).style.display = 'none';
                      document.getElementById(fin_ajax).removeAttribute("required");
                  }

                  /* cargar data a categoria ajax */
                  document.getElementById(inicio_ajax).value = momentSet(inicio_adicional[i]);
                  document.getElementById(fin_ajax).value = momentSet(fin_adicional[i]);

                  /* actualizar posicicion de tr ajax */
                  posicion_ajax = parseInt(i) + 1;
                  localStorage.setItem("contador_ajax", posicion_ajax);
              }
          };
      }

      $('#form_guardar_programado').validate({
          submitHandler: function(form) {

              var _token = $("input[name='_token']").val();
              var tipo = @json($tipo);

              /* data categoria inicial */
              var id_inicial = [];
              var categoria_inicial = [0];
              var monto_inicial = [];
              var frecuencia_inicial = [];
              var sin_caducidad_inicial = [];
              var inicio_inicial = [];
              var fin_inicial = [];
              var vistaCategoriaInicial = @json($vistaCategorias);

              for (var i = 0; i < vistaCategoriaInicial.length; ++i) {
                  if (!!document.getElementById("monto_" + vistaCategoriaInicial[i].id) == true) {
                      categoria_inicial[i] = vistaCategoriaInicial[i].id;
                      id_inicial[i] = $("#id_" + vistaCategoriaInicial[i].id).val();
                      monto_inicial[i] = $("#monto_" + vistaCategoriaInicial[i].id).val();
                      frecuencia_inicial[i] = $("#frecuencia_" + vistaCategoriaInicial[i].id).val();
                      sin_caducidad_inicial[i] = document.getElementById("sin_caducidad_" +
                          vistaCategoriaInicial[i].id).checked;
                      inicio_inicial[i] = momentGet($("#inicio_" + vistaCategoriaInicial[i].id).val());
                      fin_inicial[i] = momentGet($("#fin_" + vistaCategoriaInicial[i].id).val());
                  }
              }

              /* data categoria adicional */
              var categoria_adicional = [];
              var monto_adicional = [];
              var frecuencia_adicional = [];
              var sin_caducidad_adicional = [];
              var inicio_adicional = [];
              var fin_adicional = [];
              var cantidad_tr = @json($cantidad_tr);
              var id_categoria = @json($id);
              var comercial = @json($comercial);

              for (var i = 0; i < cantidad_tr; ++i) {
                  categoria_adicional[i] = $("#subcategoria_adicional_" + i).val();
                  monto_adicional[i] = $("#monto_adicional_" + i).val();
                  frecuencia_adicional[i] = $("#frecuencia_adicional_" + i).val();
                  sin_caducidad_adicional[i] = document.getElementById("sin_caducidad_adicional_" +
                      i).checked;
                  inicio_adicional[i] = momentGet($("#inicio_adicional_" + i).val());
                  fin_adicional[i] = momentGet($("#fin_adicional_" + i).val());
              }

              /* data categoria ajax */
              var id_ajax = [];
              var id_categoria_ajax = [];
              var monto_ajax = [];
              var frecuencia_ajax = [];
              var sin_caducidad_ajax = [];
              var inicio_ajax = [];
              var fin_ajax = [];

              for (var i = 0; i < cantidad_tr; ++i) {
                  id_ajax[i] = $("#id_ajax_" + i).val();
                  id_categoria_ajax[i] = $("#id_categoria_ajax_" + i).val();
                  monto_ajax[i] = $("#monto_ajax_" + i).val();
                  frecuencia_ajax[i] = $("#frecuencia_ajax_" + i).val();
                  sin_caducidad_ajax[i] = document.getElementById("sin_caducidad_ajax_" +
                      i).checked;
                  inicio_ajax[i] = momentGet($("#inicio_ajax_" + i).val());
                  fin_ajax[i] = momentGet($("#fin_ajax_" + i).val());
              }

              /* data categoria search */
              var id_search = [];
              var id_categoria_search = [];
              var monto_search = [];
              var frecuencia_search = [];
              var sin_caducidad_search = [];
              var inicio_search = [];
              var fin_search = [];

              for (var i = 0; i < cantidad_tr; ++i) {
                  id_search[i] = $("#id_search_" + i).val();
                  id_categoria_search[i] = $("#id_categoria_search_" + i).val();
                  monto_search[i] = $("#monto_search_" + i).val();
                  frecuencia_search[i] = $("#frecuencia_search_" + i).val();
                  sin_caducidad_search[i] = document.getElementById("sin_caducidad_search_" +
                      i).checked;
                  inicio_search[i] = momentGet($("#inicio_search_" + i).val());
                  fin_search[i] = momentGet($("#fin_search_" + i).val());
              }

              console.log(id_categoria_ajax);

              $.ajax({
                  url: "{{ route('presupuestosprogramados.store') }}",
                  type: 'POST',
                  data: {
                      _token: _token,
                      tipo: tipo,

                      categoria_inicial: categoria_inicial,
                      id_inicial: id_inicial,
                      monto_inicial: monto_inicial,
                      frecuencia_inicial: frecuencia_inicial,
                      sin_caducidad_inicial: sin_caducidad_inicial,
                      inicio_inicial: inicio_inicial,
                      fin_inicial: fin_inicial,

                      categoria_adicional: categoria_adicional,
                      monto_adicional: monto_adicional,
                      frecuencia_adicional: frecuencia_adicional,
                      sin_caducidad_adicional: sin_caducidad_adicional,
                      inicio_adicional: inicio_adicional,
                      fin_adicional: fin_adicional,
                      id_categoria: id_categoria,
                      comercial: comercial,
                      cantidad_tr: cantidad_tr,

                      id_ajax: id_ajax,
                      id_categoria_ajax: id_categoria_ajax,
                      monto_ajax: monto_ajax,
                      frecuencia_ajax: frecuencia_ajax,
                      sin_caducidad_ajax: sin_caducidad_ajax,
                      inicio_ajax: inicio_ajax,
                      fin_ajax: fin_ajax,

                      id_search: id_search,
                      id_categoria_search: id_categoria_search,
                      monto_search: monto_search,
                      frecuencia_search: frecuencia_search,
                      sin_caducidad_search: sin_caducidad_search,
                      inicio_search: inicio_search,
                      fin_search: fin_search
                  },
                  success: function(data) {
                      printMsg(data);
                      localStorage.setItem("contador_adicional", 0);
                      cargarTablaInicial(data);
                      cargarTablaAdicional(data);
                  }
              });

          }
      });

      $("#select_categoria").on("change", function() {

          var _token = $("input[name='_token']").val();
          var ano_actual = $("#ano_actual").val();
          var mes_actual = $("#mes_actual").val();
          var llave_form = 1;
          var tipo = @json($tipo);
          var id_categoria = $("#select_categoria").val();

          $.ajax({
              url: "{{ route('presupuestosprogramados.cambiar_fecha') }}",
              type: 'POST',
              data: {
                  _token: _token,
                  ano_actual: ano_actual,
                  mes_actual: mes_actual,
                  llave_form: llave_form,
                  tipo: tipo,
                  id_categoria: id_categoria
              },
              success: function(data) {
                  console.log(data);
                  localStorage.setItem("id_categoria", data.id_categoria);
                  localStorage.setItem("mes_actual", data.mes_actual);
                  localStorage.setItem("ano_actual", data.ano_actual);
                  localStorage.setItem("llave_ajax", 1);

                  cargarTablaSelect(data);
              }
          });
      });

      function cargarTablaSelect(data) {

          var vistaCategorias = data.vistaCategorias;
          var id_ingreso_programado = data.id_ingreso_programado;
          var monto = data.monto;
          var id_frecuencia = data.id_frecuencia;
          var caducidad = data.caducidad;
          var fecha_inicio = data.fecha_inicio;
          var fecha_fin = data.fecha_fin;
          var n_categorias = @json($vistaCategorias);

          /* ocultar categorias iniciales */
          for (var i = 0; i < n_categorias.length; ++i) {
              var tr = "tr_" + n_categorias[i].id;
              let element_exist = !!document.getElementById(tr);
              let element = document.getElementById(tr);

              if (element_exist == true) {
                  element.setAttribute("hidden", "hidden");
              }
          };

          for (var i = 0; i < vistaCategorias.length; ++i) {

              neo_i = i;

              /* mostrar categorias ajax */
              var tr_ajax = "tr_ajax_" + neo_i;
              let element_ajax = document.getElementById(tr_ajax);
              element_ajax.removeAttribute("hidden", "hidden");

              /* cargar data a categoria ajax */
              id_ajax = "id_ajax_" + neo_i;
              id_categoria_ajax = "id_categoria_ajax_" + neo_i;
              categoria_ajax = "categoria_ajax_" + neo_i;
              monto_ajax = "monto_ajax_" + neo_i;
              frecuencia_ajax = "frecuencia_ajax_" + neo_i;
              sin_caducidad_ajax = "sin_caducidad_ajax_" + neo_i;
              inicio_ajax = "inicio_ajax_" + neo_i;
              fin_ajax = "fin_ajax_" + neo_i;
              div_ajax = "div_ajax_" + neo_i;
              div2_ajax = "div2_ajax_" + neo_i;


              /* resetear categorias ajax */
              document.getElementById(id_ajax).value = '';
              document.getElementById(id_categoria_ajax).value = '';
              document.getElementById(monto_ajax).value = '';
              document.getElementById(monto_ajax).removeAttribute("required");
              document.getElementById(frecuencia_ajax).value = '';
              document.getElementById(frecuencia_ajax).removeAttribute("required");
              document.getElementById(sin_caducidad_ajax).checked = false;
              document.getElementById(sin_caducidad_ajax).removeAttribute("required");
              document.getElementById(inicio_ajax).value = '';
              document.getElementById(inicio_ajax).removeAttribute("required");
              document.getElementById(fin_ajax).value = '';
              document.getElementById(fin_ajax).removeAttribute("required");
              document.getElementById(div_ajax).style.display = 'initial';
              document.getElementById(div2_ajax).style.display = 'initial';

              /* Categorias Ajax */
              document.getElementById(categoria_ajax).innerHTML = vistaCategorias[i].categoria;
              document.getElementById(id_categoria_ajax).value = vistaCategorias[i].id;

              if (monto[vistaCategorias[i].id] > 0) {

                  document.getElementById(id_ajax).value = id_ingreso_programado[vistaCategorias[i].id];
                  document.getElementById(monto_ajax).value = monto[vistaCategorias[i].id];
                  document.getElementById(frecuencia_ajax).value = id_frecuencia[vistaCategorias[i].id];

                  if (caducidad[vistaCategorias[i].id] == 1) {
                      document.getElementById(sin_caducidad_ajax).checked = true;
                  }

                  document.getElementById(inicio_ajax).value = momentSet(fecha_inicio[vistaCategorias[i].id]);
                  document.getElementById(fin_ajax).value = momentSet(fecha_fin[vistaCategorias[i].id]);

                  /* reglas de validacion */
                  if (id_frecuencia[vistaCategorias[i].id] == 1) {
                      document.getElementById(inicio_ajax).setAttribute("required", "");
                      document.getElementById(div_ajax).style.display = 'none';
                      document.getElementById(fin_ajax).removeAttribute("required");
                      document.getElementById(div2_ajax).style.display = 'none';
                      document.getElementById(sin_caducidad_ajax).removeAttribute("required");
                  }

                  if (id_frecuencia[vistaCategorias[i].id] > 1) {
                      document.getElementById(inicio_ajax).setAttribute("required", "");
                      document.getElementById(div_ajax).style.display = 'initial';
                      document.getElementById(fin_ajax).setAttribute("required", "");
                      document.getElementById(div2_ajax).style.display = 'initial';
                  }

                  if (id_frecuencia[vistaCategorias[i].id] == 1) {
                      document.getElementById(sin_caducidad_ajax).checked = true;
                      document.getElementById(div_ajax).style.display = 'none';
                      document.getElementById(fin_ajax).removeAttribute("required");
                  }

                  if (caducidad[vistaCategorias[i].id] == 1) {
                      document.getElementById(div_ajax).style.display = 'none';
                      document.getElementById(fin_ajax).removeAttribute("required");
                  }
              }
          }
      }

      function totalProgramado() {
          var _token = $("input[name='_token']").val();
          var ano_actual = $("#ano_actual").val();
          var mes_actual = $("#mes_actual").val();
          var llave_form = 1;
          var tipo = @json($tipo);
          var id_categoria = $("#select_categoria").val();

          $.ajax({
              url: "{{ route('presupuestosprogramados.total_programado') }}",
              type: 'POST',
              data: {
                  _token: _token,
                  ano_actual: ano_actual,
                  mes_actual: mes_actual,
                  llave_form: llave_form,
                  tipo: tipo,
                  id_categoria: id_categoria
              },
              success: function(data) {
                  console.log(data);
                  $("#total_programado span").text(data.monto_total);
              }
          });
      }
  </script>

  <script>
      $(document).ready(function() {
          jQuery.extend(jQuery.validator.messages, {
              required: "<h4>Este campo es obligatorio.</h4>",
          });
      });
  </script>

  <script>
      $(document).on('click', '#addRowCategoria', function() {
          var tr_adicional = parseInt(localStorage.getItem("contador_adicional"));
          var tr_hidden = "tr_adicional_" + tr_adicional;
          let element = document.getElementById(tr_hidden);
          element.removeAttribute("hidden", "hidden");
          var neo_value = tr_adicional + 1;
          localStorage.setItem("contador_adicional", neo_value);
      });
  </script>
