
<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/defaults-es_ES.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" action="<?php echo e(route('categorias.update_categoria')); ?>" autocomplete="off"
                        class="form-horizontal">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>

                        <div class="card ">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><?php echo e(__('Nueva Categoria')); ?></h4>
                                <p class="card-category"><?php echo e(__('')); ?></p>
                            </div>
                            <div class="card-body ">
                                <?php if(session('status')): ?>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert"
                                                    aria-label="Close">
                                                    <i class="material-icons">close</i>
                                                </button>
                                                <span><?php echo e(session('status')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="row">

                                    <div class="col-sm">
                                        <div class="form-group">
                                            <label for="exampleFormControlSelect1">Tipo de Categoria</label>
                                            <select class="form-control" id="_tipo_categoria" name="tipo_categoria"
                                                required>
                                                <option value="">Seleccione Tipo de Categoria</option>
                                                <?php $__currentLoopData = $categoriaTipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriaTipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($categoriaTipo->id); ?>"
                                                        <?php if($categoriaTipo->id == $vistaCategoriaPadre->orden_tipo): ?> selected <?php endif; ?>>
                                                        <?php echo e($categoriaTipo->tipo_categoria); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <input type="hidden" value="<?php echo e($vistaCategoriaPadre->id); ?>"
                                                name="id_categoria">
                                        </div>
                                    </div>

                                    <div class="col-sm">
                                        <label for="exampleFormControlSelect1">Nombre Categoria</label>
                                        <div class="col-sm-7">
                                            <div class="form-group<?php echo e($errors->has('categoria') ? ' has-danger' : ''); ?>">
                                                <input
                                                    class="form-control<?php echo e($errors->has('categoria') ? ' is-invalid' : ''); ?>"
                                                    name="categoria" id="categoria" type="text"
                                                    placeholder="<?php echo e(__('Categoria')); ?>"
                                                    value="<?php echo e($vistaCategoriaPadre->categoria); ?>" required />
                                                <?php if($errors->has('categoria')): ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="row">
                                    <div class="col-sm">
                                        <div class="form-group">
                                            <label for="exampleFormControlSelect1">Logo Categoria</label>
                                            <select class="form-control selectpicker" id="_logo_categoria"
                                                name="logo_categoria" required>
                                                <option value="">Seleccione Logo</option>
                                                <?php $__currentLoopData = $categoriaLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriaLogo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($categoriaLogo->icono); ?> <?php echo e($categoriaLogo->tamano); ?>"
                                                        data-icon="<?php echo e($categoriaLogo->icono); ?>"
                                                        <?php if($categoriaLogo->icono == str_replace(' fa-2x', '', $vistaCategoriaPadre->icono)): ?> selected <?php endif; ?>>
                                                        - <?php echo e($categoriaLogo->label); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm">
                                        <div class="form-group">
                                            <label for="exampleFormControlSelect1">Fondo Categoria</label>
                                            <select class="form-control selectpicker" id="_fondo_categoria"
                                                name="fondo_categoria" required>
                                                <option value="">Seleccione Fondo Categoria</option>
                                                <option value="bg-secondary" class="bg-secondary"
                                                    <?php if($vistaCategoriaPadre->fondo == 'bg-secondary'): ?> selected <?php endif; ?>>
                                                    Plomo</option>
                                                <option value="bg-primary" class="bg-primary"
                                                    <?php if($vistaCategoriaPadre->fondo == 'bg-primary'): ?> selected <?php endif; ?>>
                                                    Azul</option>
                                                <option value="bg-danger" class="bg-danger"
                                                    <?php if($vistaCategoriaPadre->fondo == 'bg-danger'): ?> selected <?php endif; ?>>
                                                    Rojo</option>
                                                <option value="bg-warning" class="bg-warning"
                                                    <?php if($vistaCategoriaPadre->fondo == 'bg-warning'): ?> selected <?php endif; ?>>
                                                    Amarillo</option>
                                                <option value="bg-info" class="bg-info"
                                                    <?php if($vistaCategoriaPadre->fondo == 'bg-info'): ?> selected <?php endif; ?>>
                                                    Celeste</option>
                                                <option value="bg-dark" class="bg-dark" style="color: #fff"
                                                    <?php if($vistaCategoriaPadre->fondo == 'bg-dark'): ?> selected <?php endif; ?>>
                                                    Negro</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="card-footer ml-auto mr-auto">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'categorias', 'titlePage' => __('Nueva Categoria')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefix\resources\views/categorias/edit_categoria.blade.php ENDPATH**/ ?>