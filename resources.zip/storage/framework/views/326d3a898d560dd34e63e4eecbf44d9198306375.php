
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-3">
                    <a class="btn btn-primary" href="<?php echo e(route('categorias.create_categoria')); ?>" role="button">
                        + Nueva Categoria
                    </a>
                </div>
                <div class="col-md-3">
                    <a class="btn btn-primary" href="<?php echo e(route('categorias.create')); ?>" role="button">
                        + Nueva Subcategoria
                    </a>
                </div>
                <div class="col-md-3"></div>
                <div class="col-md-12"></div>
            </div>

            <div class="row">

                <?php $__currentLoopData = $vistaCategoriaPadres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistaCategoriaPadre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($vistaCategoriaPadre->plantilla == 1): ?>
                        <div class="col-md-3">
                            <div class="card text-white <?php echo e($vistaCategoriaPadre->fondo); ?> mb-3 text-center"
                                style="max-width: 18rem;">
                                <div class="card-header"><i class="<?php echo e($vistaCategoriaPadre->icono); ?>"></i></div>
                                <div class="card-body">
                                    <h5 class="card-title">

                                        <?php switch($menu):
                                            case (1): ?>
                                                <a
                                                    href="<?php echo e(route('presupuestosprogramados.create', [
                                                        'id' => $vistaCategoriaPadre->id,
                                                        'menu' => $menu,
                                                        'ano' => $ano_actual,
                                                        'mes' => $mes_actual,
                                                        'estado' => $estado,
                                                    ])); ?>"><?php echo e($vistaCategoriaPadre->categoria); ?></a>
                                            <?php break; ?>

                                            <?php case (2): ?>
                                                <a
                                                    href="<?php echo e(route('presupuestosejecutados.create', [
                                                        'id' => $vistaCategoriaPadre->id,
                                                        'menu' => $menu,
                                                        'date' => $fecha_actual,
                                                        'estado' => $estado,
                                                    ])); ?>"><?php echo e($vistaCategoriaPadre->categoria); ?></a>
                                            <?php break; ?>

                                            <?php case (3): ?>
                                                <a
                                                    href="<?php echo e(route('presupuestosprogramados.create', [
                                                        'id' => $vistaCategoriaPadre->id,
                                                        'menu' => $menu,
                                                        'ano' => $ano_actual,
                                                        'mes' => $mes_actual,
                                                        'estado' => $estado,
                                                    ])); ?>"><?php echo e($vistaCategoriaPadre->categoria); ?></a>
                                            <?php break; ?>

                                            <?php case (4): ?>
                                                <a
                                                    href="<?php echo e(route('presupuestosejecutados.create', [
                                                        'id' => $vistaCategoriaPadre->id,
                                                        'menu' => $menu,
                                                        'date' => $fecha_actual,
                                                        'estado' => $estado,
                                                    ])); ?>"><?php echo e($vistaCategoriaPadre->categoria); ?></a>
                                            <?php break; ?>
                                        <?php endswitch; ?>

                                    </h5>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php if($vistaCategoriaPadre->id_user == auth()->id()): ?>
                            <div class="col-md-3">
                                <div class="card text-white <?php echo e($vistaCategoriaPadre->fondo); ?> mb-3 text-center"
                                    style="max-width: 18rem;">
                                    <div class="card-header"><i class="<?php echo e($vistaCategoriaPadre->icono); ?>"></i></div>
                                    <div class="card-body">
                                        <h5 class="card-title">

                                            <?php switch($menu):
                                                case (1): ?>
                                                    <a
                                                        href="<?php echo e(route('presupuestosprogramados.create', [
                                                            'id' => $vistaCategoriaPadre->id,
                                                            'menu' => $menu,
                                                            'ano' => $ano_actual,
                                                            'mes' => $mes_actual,
                                                            'estado' => $estado, 
                                                        ])); ?>"><?php echo e($vistaCategoriaPadre->categoria); ?></a>
                                                <?php break; ?>

                                                <?php case (2): ?>
                                                    <a
                                                        href="<?php echo e(route('presupuestosejecutados.create', [
                                                            'id' => $vistaCategoriaPadre->id,
                                                            'menu' => $menu,
                                                            'date' => $fecha_actual,
                                                            'estado' => $estado,
                                                        ])); ?>"><?php echo e($vistaCategoriaPadre->categoria); ?></a>
                                                <?php break; ?>

                                                <?php case (3): ?>
                                                    <a
                                                        href="<?php echo e(route('presupuestosprogramados.create', [
                                                            'id' => $vistaCategoriaPadre->id,
                                                            'menu' => $menu,
                                                            'ano' => $ano_actual,
                                                            'mes' => $mes_actual,
                                                            'estado' => $estado,
                                                        ])); ?>"><?php echo e($vistaCategoriaPadre->categoria); ?></a>
                                                <?php break; ?>

                                                <?php case (4): ?>
                                                    <a
                                                        href="<?php echo e(route('presupuestosejecutados.create', [
                                                            'id' => $vistaCategoriaPadre->id,
                                                            'menu' => $menu,
                                                            'date' => $fecha_actual,
                                                            'estado' => $estado,
                                                        ])); ?>"><?php echo e($vistaCategoriaPadre->categoria); ?></a>
                                                <?php break; ?>
                                            <?php endswitch; ?>

                                        </h5>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'categorias', 'titlePage' => __('Categorias')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefix\resources\views/categorias/index.blade.php ENDPATH**/ ?>