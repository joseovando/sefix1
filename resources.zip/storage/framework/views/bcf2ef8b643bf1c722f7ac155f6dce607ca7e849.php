

<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/gijgo.min.js')); ?>" type="text/javascript"></script>
<link href="<?php echo e(asset('css/gijgo.min.css')); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo e(asset('js/messages.es-es.js')); ?>" type="text/javascript"></script>

<script>
    function nav(value) {
        if (value != "") {
            location.href = value;
        }
    }
</script>

<script>
    $(function() {
        var estado = JSON.parse(`<?php echo $estado; ?>`);
        if (estado == 1) {
            md.showNotification('top', 'right').notify({});
        }
    });
</script>

<style>
    textarea,
    input {
        padding: 10px;
        font-family: FontAwesome, "Open Sans", Verdana, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: inherit;
    }

</style>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title"><?php echo e(__($titulo)); ?></h4>
                            <p class="card-category"><?php echo e(__('')); ?></p>
                        </div>
                        <div class="card-body">

                            <form method="get"
                                action="<?php echo e(route('presupuestosejecutados.create', [
                                    'id' => $id_categoria,
                                    'menu' => $menu,
                                    'date' => $date,
                                    'estado' => $estado,
                                ])); ?>"
                                autocomplete="off" class="form-horizontal">
                                <div class="row">

                                    <div class="col-sm">

                                        <div class="form-group">
                                            <input id="date" width="276" name="date" value="<?php echo e($date); ?>" />
                                            <script>
                                                $('#date').datepicker({
                                                    showOtherMonths: true,
                                                    locale: 'es-es',
                                                    format: 'yyyy-mm-dd',
                                                    weekStartDay: 1
                                                });
                                            </script>
                                        </div>
                                    </div>
                                    <div class="col-sm">
                                        <button type="submit"
                                            class="btn btn-primary"><?php echo e(__('Cambiar Rango de Fechas')); ?></button>
                                    </div>
                                    <div class="col-sm">
                                        <input type="hidden" name="id_categoria" value="<?php echo e($id_categoria); ?>">
                                        <input type="hidden" name="date_original" value="<?php echo e($date); ?>">
                                        <input type="hidden" name="llave_form" value="1">
                                    </div>
                                </div>
                            </form>

                            <br>

                            <form method="post" action="<?php echo e(route('presupuestosejecutados.store')); ?>" autocomplete="off"
                                class="form-horizontal">

                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th scope="col">
                                                        <div class="form-group">
                                                            <select onChange=nav(this.value) class="form-control"
                                                                id="categoria" name="categoria">
                                                                <?php $__currentLoopData = $vistaCategoriaPadres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistaCategoriaPadre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($vistaCategoriaPadre->plantilla == 1): ?>
                                                                        <option
                                                                            value="<?php echo e(route('presupuestosejecutados.create', [
                                                                                'id' => $vistaCategoriaPadre->id,
                                                                                'menu' => $menu,
                                                                                'date' => $date,
                                                                                'estado' => $estado,
                                                                            ])); ?>"
                                                                            <?php if($id_categoria == $vistaCategoriaPadre->id): ?> selected <?php endif; ?>>
                                                                            <?php echo e($vistaCategoriaPadre->categoria); ?>

                                                                        </option>
                                                                    <?php else: ?>
                                                                        <?php if($vistaCategoriaPadre->id_user == auth()->id()): ?>
                                                                            <option
                                                                                value="<?php echo e(route('presupuestosejecutados.create', [
                                                                                    'id' => $vistaCategoriaPadre->id,
                                                                                    'menu' => $menu,
                                                                                    'date' => $date,
                                                                                    'estado' => $estado,
                                                                                ])); ?>"
                                                                                <?php if($id_categoria == $vistaCategoriaPadre->id): ?> selected <?php endif; ?>>
                                                                                <?php echo e($vistaCategoriaPadre->categoria); ?>

                                                                            </option>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <input type="hidden" name="id_categoria"
                                                                value="<?php echo e($id_categoria); ?>">
                                                            <input type="hidden" name="menu" value="<?php echo e($menu); ?>">
                                                            <input type="hidden" name="tipo" value="<?php echo e($tipo); ?>">
                                                            <input type="hidden" name="date" value="<?php echo e($date); ?>">
                                                        </div>
                                                    </th>
                                                    <?php for($i = 0; $i <= $n_inputs; $i++): ?>
                                                        <th scope="col"><?php echo e($calendario[$i]); ?></th>
                                                    <?php endfor; ?>
                                                    <th scope="col">Total Ejecutado Mes</th>
                                                    <th scope="col">Total Programado Mes</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php $__currentLoopData = $vistaCategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistaCategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($vistaCategoria->plantilla == 1): ?>
                                                        <tr>
                                                            <th scope="row"><?php echo e($vistaCategoria->categoria); ?></th>
                                                            <?php for($i = 0; $i <= $n_inputs; $i++): ?>
                                                                <td>
                                                                    <div class="input-group mb-3">

                                                                        <input type="text" class="form-control"
                                                                            name="<?php echo e($vistaCategoria->id); ?>_<?php echo e($fechas[$i]); ?>"
                                                                            style="font-family: FontAwesome"
                                                                            placeholder="&#xf0d6;"
                                                                            <?php if(isset($egreso[$i][$vistaCategoria->id])): ?> value="<?php echo e($egreso[$i][$vistaCategoria->id]); ?>" <?php endif; ?>
                                                                            onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;">

                                                                        <a href="" data-toggle="modal"
                                                                            data-target="#modal_<?php echo e($vistaCategoria->id); ?>_<?php echo e($fechas[$i]); ?>"><i
                                                                                class="material-icons">description</i></a>

                                                                        <div id="modal_<?php echo e($vistaCategoria->id); ?>_<?php echo e($fechas[$i]); ?>"
                                                                            class="modal fade" tabindex="-1"
                                                                            role="dialog"
                                                                            aria-labelledby="exampleModalPopoversLabel"
                                                                            style="display: none;" aria-hidden="true">
                                                                            <div class="modal-dialog" role="document">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <h5 class="modal-title"
                                                                                            id="exampleModalPopoversLabel">
                                                                                            Detalle
                                                                                        </h5>
                                                                                        <button type="button"
                                                                                            class="close"
                                                                                            data-dismiss="modal"
                                                                                            aria-label="Close">
                                                                                            <span
                                                                                                aria-hidden="true">×</span>
                                                                                        </button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="form-group">
                                                                                            <label
                                                                                                for="exampleFormControlTextarea1">Detalle</label>
                                                                                            <?php if(isset($detalle[$i][$vistaCategoria->id])): ?>
                                                                                                <textarea class="form-control" name="detalle_<?php echo e($vistaCategoria->id); ?>_<?php echo e($fechas[$i]); ?>"
                                                                                                    rows="5"><?php echo e($detalle[$i][$vistaCategoria->id]); ?></textarea>
                                                                                            <?php else: ?>
                                                                                                <textarea class="form-control" name="detalle_<?php echo e($vistaCategoria->id); ?>_<?php echo e($fechas[$i]); ?>" rows="3"></textarea>
                                                                                            <?php endif; ?>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="modal-footer">
                                                                                        <button type="button"
                                                                                            class="btn btn-secondary"
                                                                                            data-dismiss="modal">Cerrar</button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </td>
                                                            <?php endfor; ?>

                                                            <?php if($total_ejecutado_subcategoria[$vistaCategoria->id] > 0): ?>
                                                                <th scope="row" bgcolor="#fec87c">
                                                                    <?php echo e($total_ejecutado_subcategoria[$vistaCategoria->id]); ?>

                                                                </th>
                                                            <?php else: ?>
                                                                <th scope="row" bgcolor="#fec87c"></th>
                                                            <?php endif; ?>

                                                            <?php if($total_programado_subcategoria[$vistaCategoria->id] > 0): ?>
                                                                <th scope="row" bgcolor="#0cd0e8">
                                                                    <?php echo e($total_programado_subcategoria[$vistaCategoria->id]); ?>

                                                                </th>
                                                            <?php else: ?>
                                                                <th scope="row" bgcolor="#0cd0e8"></th>
                                                            <?php endif; ?>

                                                        </tr>
                                                    <?php else: ?>
                                                        <?php if($vistaCategoria->id_user == auth()->id()): ?>
                                                            <tr>
                                                                <th scope="row"><?php echo e($vistaCategoria->categoria); ?></th>
                                                                <?php for($i = 0; $i <= $n_inputs; $i++): ?>
                                                                    <td>
                                                                        <div class="input-group mb-3">

                                                                            <input type="text" class="form-control"
                                                                                name="<?php echo e($vistaCategoria->id); ?>_<?php echo e($fechas[$i]); ?>"
                                                                                style="font-family: FontAwesome"
                                                                                placeholder="&#xf0d6;"
                                                                                <?php if(isset($egreso[$i][$vistaCategoria->id])): ?> value="<?php echo e($egreso[$i][$vistaCategoria->id]); ?>" <?php endif; ?>
                                                                                onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;">

                                                                            <a href="" data-toggle="modal"
                                                                                data-target="#modal_<?php echo e($vistaCategoria->id); ?>_<?php echo e($fechas[$i]); ?>"><i
                                                                                    class="material-icons">description</i></a>

                                                                            <div id="modal_<?php echo e($vistaCategoria->id); ?>_<?php echo e($fechas[$i]); ?>"
                                                                                class="modal fade" tabindex="-1"
                                                                                role="dialog"
                                                                                aria-labelledby="exampleModalPopoversLabel"
                                                                                style="display: none;" aria-hidden="true">
                                                                                <div class="modal-dialog" role="document">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <h5 class="modal-title"
                                                                                                id="exampleModalPopoversLabel">
                                                                                                Detalle
                                                                                            </h5>
                                                                                            <button type="button"
                                                                                                class="close"
                                                                                                data-dismiss="modal"
                                                                                                aria-label="Close">
                                                                                                <span
                                                                                                    aria-hidden="true">×</span>
                                                                                            </button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            <div class="form-group">
                                                                                                <label
                                                                                                    for="exampleFormControlTextarea1">Detalle</label>
                                                                                                <?php if(isset($detalle[$i][$vistaCategoria->id])): ?>
                                                                                                    <blade
                                                                                                        ___html_tags_2___ />
                                                                                                <?php else: ?>
                                                                                                    <blade
                                                                                                        ___html_tags_3___ />
                                                                                                <?php endif; ?>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="modal-footer">
                                                                                            <button type="button"
                                                                                                class="btn btn-secondary"
                                                                                                data-dismiss="modal">Cerrar</button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </td>
                                                                <?php endfor; ?>

                                                                <?php if($total_ejecutado_subcategoria[$vistaCategoria->id] > 0): ?>
                                                                    <th scope="row" bgcolor="#fec87c">
                                                                        <?php echo e($total_ejecutado_subcategoria[$vistaCategoria->id]); ?>

                                                                    </th>
                                                                <?php else: ?>
                                                                    <th scope="row" bgcolor="#fec87c"></th>
                                                                <?php endif; ?>

                                                                <?php if($total_programado_subcategoria[$vistaCategoria->id] > 0): ?>
                                                                    <th scope="row" bgcolor="#0cd0e8">
                                                                        <?php echo e($total_programado_subcategoria[$vistaCategoria->id]); ?>

                                                                    </th>
                                                                <?php else: ?>
                                                                    <th scope="row" bgcolor="#0cd0e8"></th>
                                                                <?php endif; ?>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <th scope="row">Total</th>
                                                    <?php for($i = 0; $i <= $n_inputs; $i++): ?>
                                                        <?php if($total_monto_dia[$i] > 0): ?>
                                                            <th scope="row" bgcolor="#7adf7f" align="right">
                                                                <?php echo e($total_monto_dia[$i]); ?></th>
                                                        <?php else: ?>
                                                            <th scope="row" bgcolor="#7adf7f" align="right"></th>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                    <th scope="row" bgcolor="#fec87c" align="right">
                                                        <?php echo e($total_ejecutado_mes); ?></th>
                                                    <th scope="row" bgcolor="#0cd0e8" align="right">
                                                        <?php echo e($total_programado_mes); ?></th>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="card-footer ml-auto mr-auto">
                                        <button type="submit"
                                            class="save-button first btn btn-primary"><?php echo e(__('Guardar')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'presupuestosejecutados', 'titlePage' => __($titulo)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefix\resources\views/presupuestosejecutados/create.blade.php ENDPATH**/ ?>