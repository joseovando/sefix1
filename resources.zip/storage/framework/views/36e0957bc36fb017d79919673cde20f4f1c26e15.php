<footer class="footer">
  <div class="container-fluid">
    <nav class="float-left">
      <ul>
        <li>
          <a href="https://www.creative-tim.com">
            <?php echo e(__('SEFIS')); ?>

          </a>
        </li>
        <li>
          <a href="https://creative-tim.com/presentation">
            <?php echo e(__('About Us')); ?>

          </a>
        </li>
        <li>
          <a href="http://blog.creative-tim.com">
            <?php echo e(__('Blog')); ?>

          </a>
        </li>
        <li>
          <a href="https://www.creative-tim.com/license">
            <?php echo e(__('Licenses')); ?>

          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script> <i class="material-icons">favorite</i> by
      <a href="https://www.creative-tim.com" target="_blank"> Semilla Financiera de Salomón</a>
    </div>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\sefix\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>