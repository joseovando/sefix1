<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/buttons.dataTables.min.css')); ?>">

<script type="text/javascript" language="javascript" src="<?php echo e(asset('js/jquery-3.5.1.js')); ?>"></script>
<script type="text/javascript" language="javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" language="javascript" src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
<script type="text/javascript" language="javascript" src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
<script type="text/javascript" language="javascript" src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
<script type="text/javascript" language="javascript" src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
<script type="text/javascript" language="javascript" src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>

<script type="text/javascript" class="init">
    $(document).ready(function() {
        $('#example').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copyHtml5',
                'pdfHtml5'
            ]
        });
        $('#example2').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copyHtml5',
                'pdfHtml5'
            ]
        });
    });
</script>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">

            <form method="get"
                action="<?php echo e(route('reportes.subcategoria', [
                    'ano' => $ano_actual,
                    'mes' => $mes_actual,
                    'categoria' => $categoria,
                ])); ?>"
                autocomplete="off" class="form-horizontal">

                <div class="row">
                    <div class="col-sm">
                        <label for="exampleFormControlSelect1">Mes</label>
                    </div>
                    <div class="col-sm">
                        <div class="form-group">

                            <select class="form-control" id="ano_actual" name="ano_actual">
                                <?php for($i = $ano_actual_inicio; $i <= $ano_actual_fin; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php if($i == $ano_actual): ?> selected <?php endif; ?>>
                                        <?php echo e($i); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>

                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="form-group">

                            <select class="form-control" id="mes_actual" name="mes_actual">
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php if($i == $mes_actual): ?> selected <?php endif; ?>>
                                        <?php echo e($meses[$i]); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>

                        </div>
                    </div>
                    <div class="col-sm">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Cambiar Mes')); ?></button>
                    </div>
                    <div class="col-sm">
                        <input type="hidden" name="llave_form" value="1">
                    </div>
                </div>

            </form>

            <div class="row">

                <div class="col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header card-header-rose">
                            <h4 class="card-title">Distribución Programado Ejecutado Mensual por SubCategoria</h4>
                            <p class="card-category"><?php echo e($mes_actual_text); ?></p>
                        </div>
                        <div class="card-body table-responsive">
                            <table id="example2" class="display" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Detalle</th>
                                        <th>Ejecutado</th>
                                        <th>Programado</th>
                                        <th>Diferencia Numeral</th>
                                        <th>Diferencia Porcentual</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php for($i = 0; $i < $contador; $i++): ?>
                                        <tr>
                                            <td><?php echo e($nombre_subcategoria[$i]); ?></td>
                                            <td><?php echo e(number_format($egreso_subcategoria_mes[$i], 2)); ?></td>
                                            <td><?php echo e(number_format($egreso_subcategoria_programado_mes[$i], 2)); ?></td>
                                            <td><?php echo e(number_format($diferencia_egreso_subcategoria_mes[$i], 2)); ?></td>
                                            <td><?php echo e(number_format($porcentaje_egreso_subcategoria_mes[$i], 2)); ?></td>
                                        </tr>
                                    <?php endfor; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Total</th>
                                        <th><?php echo e(number_format($total_egreso_subcategoria_mes, 2)); ?></th>
                                        <th><?php echo e(number_format($total_egreso_subcategoria_programado_mes, 2)); ?></th>
                                        <th><?php echo e(number_format($total_diferencia_egreso_subcategoria_mes, 2)); ?></th>
                                        <th><?php echo e(number_format($total_porcentaje_egreso_subcategoria_mes, 2)); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">access_time</i> Actualizado al <?php echo e($fecha_actual); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Distribución Programado Ejecutado Mensual por SubCategoria</h4>
                            <p class="card-category"><?php echo e($mes_actual_text); ?></p>
                        </div>
                        <div class="card-body table-responsive">
                            <canvas id="bar-subcategoria-mensual" height="400"></canvas>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">access_time</i> Actualizado al <?php echo e($fecha_actual); ?>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">

                <div class="col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Ingresos Corrientes</h4>
                            <p class="card-category"><?php echo e($mes_actual_text); ?></p>
                        </div>
                        <div class="card-body table-responsive">
                            <canvas id="bar-subcategoria-anual" height="300"></canvas>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">access_time</i> Actualizado al <?php echo e($fecha_actual); ?>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chartjs-plugin-labels.js')); ?>"></script>

    <script>
        const cDataNombreSubCategoria = JSON.parse(`<?php echo $data_nombre_subcategoria; ?>`);
        const cDataEgresoSubCategoriaMes = JSON.parse(`<?php echo $data_egreso_subcategoria_mes; ?>`);
        const cDataEgresoSubCategoriaProgramadoMes = JSON.parse(`<?php echo $data_egreso_subcategoria_programado_mes; ?>`);

        const cDataSubCategoriaAnual = JSON.parse(`<?php echo $data_subcategoria_anual; ?>`);
        const cDataProgramadoSubCategoriaAnual = JSON.parse(`<?php echo $data_programado_subcategoria_anual; ?>`);

        new Chart(document.getElementById('bar-subcategoria-mensual'), {
            type: 'bar',
            data: {
                labels: cDataNombreSubCategoria,
                datasets: [{
                        label: 'Ejecutado',
                        data: cDataEgresoSubCategoriaMes,
                        backgroundColor: [
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                        ]
                    },

                    {
                        label: 'Programado',
                        data: cDataEgresoSubCategoriaProgramadoMes,
                        backgroundColor: [
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                        ]
                    },
                ]
            },
            options: {
                title: {
                    display: true,
                    text: '',
                    position: 'top',
                    fontSize: 16,
                    fontColor: '#111',
                    padding: 20
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        boxWidth: 20,
                        fontColor: '#111',
                        padding: 15
                    }
                },
                tooltips: {
                    enabled: true
                },
                plugins: {
                    labels: {
                        render: 'value'
                    }
                }
            }
        });

        new Chart(document.getElementById('bar-subcategoria-anual'), {
            type: 'bar',
            data: {
                labels: ['ENE',
                    'FEB',
                    'MAR',
                    'ABR',
                    'MAY',
                    'JUN',
                    'JUL',
                    'AGO',
                    'SEP',
                    'OCT',
                    'NOV',
                    'DIC',
                ],
                datasets: [{
                        label: 'Ingreso Ejecutado',
                        data: cDataSubCategoriaAnual,
                        backgroundColor: [
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                            '#FF6384',
                        ]
                    },
                    {
                        label: 'Ingreso Programado',
                        data: cDataProgramadoSubCategoriaAnual,
                        backgroundColor: [
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                            '#36A2EB',
                        ]
                    },
                ]
            },
            options: {
                title: {
                    display: true,
                    text: '',
                    position: 'top',
                    fontSize: 16,
                    fontColor: '#111',
                    padding: 20
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        boxWidth: 20,
                        fontColor: '#111',
                        padding: 15
                    }
                },
                tooltips: {
                    enabled: true
                },
                plugins: {
                    labels: {
                        render: 'value'
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'reportes', 'titlePage' => __('Reportes')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefix\resources\views/reportes/subcategoria.blade.php ENDPATH**/ ?>