

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" action="<?php echo e(route('permissions.update', $permission)); ?>" autocomplete="off"
                        class="form-horizontal">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="card ">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><?php echo e(__('Editar Permiso')); ?></h4>
                                <p class="card-category"><?php echo e(__('')); ?></p>
                            </div>
                            <div class="card-body ">
                                <?php if(session('status')): ?>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert"
                                                    aria-label="Close">
                                                    <i class="material-icons">close</i>
                                                </button>
                                                <span><?php echo e(session('status')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="row">
                                    <input type="hidden" value="<?php echo e($permission->id); ?>" name="permission_id">
                                    <label class="col-sm-2 col-form-label"><?php echo e(__('Nombre del Permiso')); ?></label>
                                    <div class="col-sm-7">
                                        <input class="form-control" type="text" name="name"
                                            placeholder="Nombre del Permiso" value="<?php echo e(old('name', $permission->name)); ?>"
                                            required="true">
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer ml-auto mr-auto">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Editar')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Permisos', 'titlePage' => __('Permisos')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefix\resources\views/permissions/edit.blade.php ENDPATH**/ ?>