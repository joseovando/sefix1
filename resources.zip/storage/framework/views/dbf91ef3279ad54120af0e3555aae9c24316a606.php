

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" action="<?php echo e(route('roles.update', $role)); ?>" autocomplete="off"
                        class="form-horizontal">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="card ">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><?php echo e(__('Editar Rol')); ?></h4>
                                <p class="card-category"><?php echo e(__('')); ?></p>
                            </div>
                            <div class="card-body ">
                                <?php if(session('status')): ?>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert"
                                                    aria-label="Close">
                                                    <i class="material-icons">close</i>
                                                </button>
                                                <span><?php echo e(session('status')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="row">
                                    <input type="hidden" value="<?php echo e($role->id); ?>" name="role_id">
                                    <label class="col-sm-2 col-form-label"><?php echo e(__('Nombre del Permiso')); ?></label>
                                    <div class="col-sm-7">
                                        <input class="form-control" type="text" name="name"
                                            placeholder="Nombre del Permiso" value="<?php echo e(old('name', $role->name)); ?>"
                                            required="true">
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label"><?php echo e(__('Asignar Permisos')); ?></label>
                                    <div class="tab-pane active" id="profile">
                                        <table class="table">
                                            <tbody>
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <div class="form-check">
                                                                <label class="form-check-label">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        name="permissions[]" value="<?php echo e($id); ?>"
                                                                        <?php echo e($role->permissions->contains($id) ? 'checked' : ''); ?>>
                                                                    <span class="form-check-sign">
                                                                        <span class="check"></span>
                                                                    </span>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td><?php echo e($permission); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                            <div class="card-footer ml-auto mr-auto">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Editar')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Roles', 'titlePage' => __('Roles')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefix\resources\views/roles/edit.blade.php ENDPATH**/ ?>