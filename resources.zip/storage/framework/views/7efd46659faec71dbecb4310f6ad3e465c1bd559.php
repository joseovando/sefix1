
<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/defaults-es_ES.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" action="<?php echo e(route('categorias.store')); ?>" autocomplete="off"
                        class="form-horizontal">

                        <?php echo csrf_field(); ?>

                        <div class="card ">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><?php echo e(__('Nueva Subcategoria')); ?></h4>
                                <p class="card-category"><?php echo e(__('')); ?></p>
                            </div>
                            <div class="card-body ">
                                <?php if(session('status')): ?>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert"
                                                    aria-label="Close">
                                                    <i class="material-icons">close</i>
                                                </button>
                                                <span><?php echo e(session('status')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="row">
                                    <div class="col-sm">
                                        <div class="form-group">

                                            <label for="exampleFormControlSelect1">Categoria</label><br>

                                            <select class="form-control selectpicker show-tick" data-live-search="true"
                                                id="_categoria" name="categoria" required>
                                                <option value="">Seleccione Categoria</option>
                                                <optgroup label="Tipo Ingreso">
                                                    <?php $__currentLoopData = $vistaCategoriaIngresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistaCategoriaIngreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($vistaCategoriaIngreso->plantilla == 1): ?>
                                                            <option value="<?php echo e($vistaCategoriaIngreso->id); ?>">
                                                                <?php echo e($vistaCategoriaIngreso->categoria); ?>

                                                            </option>
                                                        <?php else: ?>
                                                            <?php if($vistaCategoriaIngreso->id_user == auth()->id()): ?>
                                                                <option value="<?php echo e($vistaCategoriaIngreso->id); ?>">
                                                                    <?php echo e($vistaCategoriaIngreso->categoria); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                                <optgroup label="Tipo Egreso">
                                                    <?php $__currentLoopData = $vistaCategoriaEgresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistaCategoriaEgreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($vistaCategoriaEgreso->plantilla == 1): ?>
                                                            <option value="<?php echo e($vistaCategoriaEgreso->id); ?>">
                                                                <?php echo e($vistaCategoriaEgreso->categoria); ?>

                                                            </option>
                                                        <?php else: ?>
                                                            <?php if($vistaCategoriaEgreso->id_user == auth()->id()): ?>
                                                                <option value="<?php echo e($vistaCategoriaEgreso->id); ?>">
                                                                    <?php echo e($vistaCategoriaEgreso->categoria); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm">
                                        <label for="exampleFormControlSelect1">Subcategoria</label>
                                        <div class="col-sm-7">
                                            <div
                                                class="form-group<?php echo e($errors->has('subcategoria') ? ' has-danger' : ''); ?>">
                                                <input
                                                    class="form-control<?php echo e($errors->has('subcategoria') ? ' is-invalid' : ''); ?>"
                                                    name="subcategoria" id="subcategoria" type="text"
                                                    placeholder="<?php echo e(__('subcategoria')); ?>"
                                                    value="<?php echo e(old('subcategoria', auth()->user()->subcategoria)); ?>"
                                                    required />
                                                <?php if($errors->has('subcategoria')): ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="card-footer ml-auto mr-auto">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'subcategorias', 'titlePage' => __('Nueva Subcategoria')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefix\resources\views/categorias/create.blade.php ENDPATH**/ ?>