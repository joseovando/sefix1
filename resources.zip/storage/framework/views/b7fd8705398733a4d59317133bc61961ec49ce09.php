

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('js/jquery-3.5.1.js')); ?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>

    <script type="text/javascript" class="init">
        $(document).ready(function() {
            $('#example').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'pdfHtml5'
                ]
            });
        });
    </script>

    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <a class="btn btn-primary" href="<?php echo e(route('categorias.create')); ?>" role="button">
                    + Nueva Subcategoria
                </a>
            </div>

            <br>

            <div class="row">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>Tipo</th>
                            <th>Categoria</th>
                            <th>Subcategoria</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $vistaCategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistaCategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a class="navbar-brand" href="<?php echo e(route('categorias.edit', $vistaCategoria->id)); ?>">
                                        <i class="fa fa-pencil" aria-hidden="true"></i></a>
                                </td>
                                <td>
                                    <a class="navbar-brand"
                                        href="<?php echo e(route('categorias.delete', $vistaCategoria->id)); ?>">
                                        <i class="fa fa-trash" aria-hidden="true"></i></a>
                                </td>
                                <td><?php echo e($vistaCategoria->tipo_categoria); ?></td>
                                <td><?php echo e($vistaCategoria->categoria_padre); ?></td>
                                <td><?php echo e($vistaCategoria->categoria); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>Tipo</th>
                            <th>Categoria</th>
                            <th>Subcategoria</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'subcategoria', 'titlePage' => __('Subcategoria')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefix\resources\views/categorias/tablero.blade.php ENDPATH**/ ?>